var home = "Home";
var add = "Add";
var collapse = "Collapse";
var setup = "Setup";
var setupDescription = "Connect to your Mihomo backend to get started";
var overview = "Overview";
var proxies = "Proxies";
var proxiesSettings = "Proxies Settings";
var rules = "Rules";
var connections = "Connections";
var connectionsSettings = "Connections Settings";
var connectionsDetails = "Connections Details";
var logs = "Logs";
var logsSettings = "Logs Settings";
var config = "Config";
var upload = "Upload";
var download = "Download";
var uploadTotal = "Upload Total";
var downloadTotal = "Download Total";
var activeConnections = "Active Connections";
var memoryUsage = "Memory Usage";
var flow = "Flow";
var traffic = "Traffic";
var memory = "Memory";
var down = "Down";
var up = "Up";
var proxyProviders = "Proxy Providers";
var ruleProviders = "Rule Providers";
var search = "Search";
var inner = "Inner";
var ID = "ID";
var type = "Type";
var name = "Name";
var process = "Process";
var host = "Host";
var sniffHost = "Sniff Host";
var chains = "Chains";
var connectTime = "Time";
var dlSpeed = "DL Speed";
var ulSpeed = "UL Speed";
var dl = "DL";
var ul = "UL";
var sourceIP = "Source IP";
var sourcePort = "Source Port";
var destination = "Destination";
var inboundUser = "Inbound User";
var close = "Close";
var pause = "Pause";
var resume = "Resume";
var reset = "Reset";
var resetSettings = "Reset Settings";
var dnsQuery = "DNS Query";
var dots = "Dots";
var bar = "Bar";
var auto = "Auto";
var off = "Off";
var proxiesPreviewType = "Proxies Preview Type";
var proxiesDisplayMode = "Display Mode";
var cardMode = "Card";
var listMode = "List";
var urlForLatencyTest = "URL for Latency Test";
var autoCloseConns = "Automatically Close Connections";
var autoSwitchEndpoint = "Automatically Switch Endpoint";
var autoSwitchTheme = "Automatically switch theme";
var favDayTheme = "Favorite light theme";
var favNightTheme = "Favorite dark theme";
var renderInTwoColumns = "Render In Two Columns";
var updateGEODatabases = "Update GEO Databases";
var restartCore = "Restart Core";
var upgradeCore = "Upgrade Core";
var upgradeUI = "Upgrade Dashboard";
var proxiesSorting = "Proxies Sorting";
var orderNatural = "Original order in config file";
var orderLatency_asc = "By latency from low to high";
var orderLatency_desc = "By latency from high to low";
var orderName_asc = "By name alphabetically (A-Z)";
var orderName_desc = "By name alphabetically (Z-A)";
var ms = "ms";
var updated = "Updated";
var tableSize = "Table size";
var logLevel = "Log Level";
var info = "info";
var silent = "silent";
var debug = "debug";
var warning = "warning";
var error = "error";
var logMaxRows = "Log Maximum Reserved Rows";
var xs = "Extra small size";
var sm = "Small size";
var md = "Normal size";
var lg = "Large size";
var switchEndpoint = "Switch Endpoint";
var switchLanguage = "Switch Language";
var switchFont = "Switch Font";
var enableTwemoji = "Enable Twemoji";
var latencyTestTimeoutDuration = "Latency Test Timeout Duration";
var all = "All";
var sequence = "Sequence";
var level = "Level";
var payload = "Payload";
var details = "Details";
var endpointURL = "Endpoint URL";
var secret = "Secret";
var runningMode = "Running Mode";
var global = "Global";
var rule = "Rule";
var direct = "Direct";
var reject = "Reject";
var rejectdrop = "Drop";
var selector = "Selector";
var urltest = "Urltest";
var loadbalance = "Balance";
var fallback = "Fallback";
var relay = "Relay";
var pass = "Pass";
var active = "Active";
var closed = "Closed";
var sort = "Sort";
var hideUnavailableProxies = "Hide Unavailable Proxies";
var reloadConfig = "Reload Config";
var flushFakeIP = "Flush Fake-IP";
var flushDNSCache = "Flush DNS Cache";
var tagClientSourceIPWithName = "Tag Client Source IP With Name";
var tag = "Tag";
var coreConfig = "Core Config";
var xdConfig = "XD Config";
var version = "Version";
var expire = "Expire";
var noExpire = "Null";
var allowLan = "Allow Lan";
var enableTunDevice = "Enable TUN Device";
var tunModeStack = "TUN Mode Stack";
var tunDeviceName = "TUN Device Name";
var outboundInterfaceName = "Outbound Interface Name";
var port = "{name} Port";
var quickFilter = "Quick Filter";
var iconHeight = "Icon Height";
var iconMarginRight = "Icon Margin Right";
var dataUsage = "Data Usage";
var clearAll = "Clear All";
var confirmClearAll = "Clear all data usage?";
var devices = "Devices";
var timeRange = "Time Range";
var grandTotal = "Grand Total";
var macAddress = "MAC Address";
var ipAddress = "IP Address";
var duration = "Duration";
var total = "Total";
var actions = "Actions";
var remove = "Remove";
var noDataUsageYet = "No data usage recorded yet";
var noData = "No data";
var noRules = "No rules";
var noRuleProviders = "No rule providers";
var columns = "Columns";
var sortBy = "Sort by";
var groupBy = "Group by";
var rowsPerPage = "Rows per page";
var ipShort = "IP";
var na = "N/A";
var show = "Show";
var noLatencyHistory = "No latency history";
var dataUsageInfo = "Data usage monitoring is performed on the client-side (browser). When the browser is closed, monitoring will likely not run.";
var basic = "Basic";
var start = "Start";
var rulePayload = "Rule Payload";
var metadata = "Metadata";
var network = "Network";
var dnsMode = "DNS Mode";
var sourceAndDestination = "Source & Destination";
var source = "Source";
var remoteDestination = "Remote Destination";
var inbound = "Inbound";
var inboundName = "Inbound Name";
var inboundIP = "Inbound IP";
var processName = "Process Name";
var processPath = "Process Path";
var special = "Special";
var specialProxy = "Special Proxy";
var specialRules = "Special Rules";
var connectionsChart = "Connections";
var networkTypes = "Network Types";
var topProxies = "Top Proxies";
var tcp = "TCP";
var udp = "UDP";
var other = "Other";
var showTrafficIndicator = "Show Traffic Indicator";
var hideTrafficIndicator = "Hide Traffic Indicator";
var currentIP = "Current IP";
var country = "Country";
var city = "City";
var organization = "Organization";
var proxyDetection = "Proxy Detection";
var clean = "Clean";
var networkLatency = "Network Latency";
var average = "Average";
var timeout = "Timeout";
var networkTopology = "Network Topology";
var client = "Client";
var destinations = "Destinations";
var waitingForConnections = "Waiting for connections...";
var conn = "conn";
var more = "more";
var connectedTo = "Connected to";
var clients = "Clients";
var groups = "Groups";
var nodes = "Nodes";
var proxyGroups = "Proxy Groups";
var proxyNodes = "Proxy Nodes";
var ruleType = "Rule Type";
var useMobileBottomNav = "Use Bottom Navigation (Mobile)";
const en = {
	home: home,
	add: add,
	collapse: collapse,
	setup: setup,
	setupDescription: setupDescription,
	overview: overview,
	proxies: proxies,
	proxiesSettings: proxiesSettings,
	rules: rules,
	connections: connections,
	connectionsSettings: connectionsSettings,
	connectionsDetails: connectionsDetails,
	logs: logs,
	logsSettings: logsSettings,
	config: config,
	upload: upload,
	download: download,
	uploadTotal: uploadTotal,
	downloadTotal: downloadTotal,
	activeConnections: activeConnections,
	memoryUsage: memoryUsage,
	flow: flow,
	traffic: traffic,
	memory: memory,
	down: down,
	up: up,
	proxyProviders: proxyProviders,
	ruleProviders: ruleProviders,
	search: search,
	inner: inner,
	ID: ID,
	type: type,
	name: name,
	process: process,
	host: host,
	sniffHost: sniffHost,
	chains: chains,
	connectTime: connectTime,
	dlSpeed: dlSpeed,
	ulSpeed: ulSpeed,
	dl: dl,
	ul: ul,
	sourceIP: sourceIP,
	sourcePort: sourcePort,
	destination: destination,
	inboundUser: inboundUser,
	close: close,
	pause: pause,
	resume: resume,
	reset: reset,
	resetSettings: resetSettings,
	dnsQuery: dnsQuery,
	dots: dots,
	bar: bar,
	auto: auto,
	off: off,
	proxiesPreviewType: proxiesPreviewType,
	proxiesDisplayMode: proxiesDisplayMode,
	cardMode: cardMode,
	listMode: listMode,
	urlForLatencyTest: urlForLatencyTest,
	autoCloseConns: autoCloseConns,
	autoSwitchEndpoint: autoSwitchEndpoint,
	autoSwitchTheme: autoSwitchTheme,
	favDayTheme: favDayTheme,
	favNightTheme: favNightTheme,
	renderInTwoColumns: renderInTwoColumns,
	updateGEODatabases: updateGEODatabases,
	restartCore: restartCore,
	upgradeCore: upgradeCore,
	upgradeUI: upgradeUI,
	proxiesSorting: proxiesSorting,
	orderNatural: orderNatural,
	orderLatency_asc: orderLatency_asc,
	orderLatency_desc: orderLatency_desc,
	orderName_asc: orderName_asc,
	orderName_desc: orderName_desc,
	ms: ms,
	updated: updated,
	tableSize: tableSize,
	logLevel: logLevel,
	info: info,
	silent: silent,
	debug: debug,
	warning: warning,
	error: error,
	logMaxRows: logMaxRows,
	xs: xs,
	sm: sm,
	md: md,
	lg: lg,
	switchEndpoint: switchEndpoint,
	switchLanguage: switchLanguage,
	switchFont: switchFont,
	enableTwemoji: enableTwemoji,
	latencyTestTimeoutDuration: latencyTestTimeoutDuration,
	all: all,
	sequence: sequence,
	level: level,
	payload: payload,
	details: details,
	endpointURL: endpointURL,
	secret: secret,
	runningMode: runningMode,
	global: global,
	rule: rule,
	direct: direct,
	reject: reject,
	rejectdrop: rejectdrop,
	selector: selector,
	urltest: urltest,
	loadbalance: loadbalance,
	fallback: fallback,
	relay: relay,
	pass: pass,
	active: active,
	closed: closed,
	sort: sort,
	hideUnavailableProxies: hideUnavailableProxies,
	reloadConfig: reloadConfig,
	flushFakeIP: flushFakeIP,
	flushDNSCache: flushDNSCache,
	tagClientSourceIPWithName: tagClientSourceIPWithName,
	tag: tag,
	coreConfig: coreConfig,
	xdConfig: xdConfig,
	version: version,
	expire: expire,
	noExpire: noExpire,
	allowLan: allowLan,
	enableTunDevice: enableTunDevice,
	tunModeStack: tunModeStack,
	tunDeviceName: tunDeviceName,
	outboundInterfaceName: outboundInterfaceName,
	port: port,
	quickFilter: quickFilter,
	iconHeight: iconHeight,
	iconMarginRight: iconMarginRight,
	dataUsage: dataUsage,
	clearAll: clearAll,
	confirmClearAll: confirmClearAll,
	devices: devices,
	timeRange: timeRange,
	grandTotal: grandTotal,
	macAddress: macAddress,
	ipAddress: ipAddress,
	duration: duration,
	total: total,
	actions: actions,
	remove: remove,
	noDataUsageYet: noDataUsageYet,
	noData: noData,
	noRules: noRules,
	noRuleProviders: noRuleProviders,
	columns: columns,
	sortBy: sortBy,
	groupBy: groupBy,
	rowsPerPage: rowsPerPage,
	ipShort: ipShort,
	na: na,
	show: show,
	noLatencyHistory: noLatencyHistory,
	dataUsageInfo: dataUsageInfo,
	basic: basic,
	start: start,
	rulePayload: rulePayload,
	metadata: metadata,
	network: network,
	dnsMode: dnsMode,
	sourceAndDestination: sourceAndDestination,
	source: source,
	remoteDestination: remoteDestination,
	inbound: inbound,
	inboundName: inboundName,
	inboundIP: inboundIP,
	processName: processName,
	processPath: processPath,
	special: special,
	specialProxy: specialProxy,
	specialRules: specialRules,
	connectionsChart: connectionsChart,
	networkTypes: networkTypes,
	topProxies: topProxies,
	tcp: tcp,
	udp: udp,
	other: other,
	showTrafficIndicator: showTrafficIndicator,
	hideTrafficIndicator: hideTrafficIndicator,
	currentIP: currentIP,
	country: country,
	city: city,
	organization: organization,
	proxyDetection: proxyDetection,
	clean: clean,
	networkLatency: networkLatency,
	average: average,
	timeout: timeout,
	networkTopology: networkTopology,
	client: client,
	destinations: destinations,
	waitingForConnections: waitingForConnections,
	conn: conn,
	more: more,
	connectedTo: connectedTo,
	clients: clients,
	groups: groups,
	nodes: nodes,
	proxyGroups: proxyGroups,
	proxyNodes: proxyNodes,
	ruleType: ruleType,
	useMobileBottomNav: useMobileBottomNav
};

export { ID, actions, active, activeConnections, add, all, allowLan, auto, autoCloseConns, autoSwitchEndpoint, autoSwitchTheme, average, bar, basic, cardMode, chains, city, clean, clearAll, client, clients, close, closed, collapse, columns, config, confirmClearAll, conn, connectTime, connectedTo, connections, connectionsChart, connectionsDetails, connectionsSettings, coreConfig, country, currentIP, dataUsage, dataUsageInfo, debug, en as default, destination, destinations, details, devices, direct, dl, dlSpeed, dnsMode, dnsQuery, dots, down, download, downloadTotal, duration, enableTunDevice, enableTwemoji, endpointURL, error, expire, fallback, favDayTheme, favNightTheme, flow, flushDNSCache, flushFakeIP, global, grandTotal, groupBy, groups, hideTrafficIndicator, hideUnavailableProxies, home, host, iconHeight, iconMarginRight, inbound, inboundIP, inboundName, inboundUser, info, inner, ipAddress, ipShort, latencyTestTimeoutDuration, level, lg, listMode, loadbalance, logLevel, logMaxRows, logs, logsSettings, macAddress, md, memory, memoryUsage, metadata, more, ms, na, name, network, networkLatency, networkTopology, networkTypes, noData, noDataUsageYet, noExpire, noLatencyHistory, noRuleProviders, noRules, nodes, off, orderLatency_asc, orderLatency_desc, orderName_asc, orderName_desc, orderNatural, organization, other, outboundInterfaceName, overview, pass, pause, payload, port, process, processName, processPath, proxies, proxiesDisplayMode, proxiesPreviewType, proxiesSettings, proxiesSorting, proxyDetection, proxyGroups, proxyNodes, proxyProviders, quickFilter, reject, rejectdrop, relay, reloadConfig, remoteDestination, remove, renderInTwoColumns, reset, resetSettings, restartCore, resume, rowsPerPage, rule, rulePayload, ruleProviders, ruleType, rules, runningMode, search, secret, selector, sequence, setup, setupDescription, show, showTrafficIndicator, silent, sm, sniffHost, sort, sortBy, source, sourceAndDestination, sourceIP, sourcePort, special, specialProxy, specialRules, start, switchEndpoint, switchFont, switchLanguage, tableSize, tag, tagClientSourceIPWithName, tcp, timeRange, timeout, topProxies, total, traffic, tunDeviceName, tunModeStack, type, udp, ul, ulSpeed, up, updateGEODatabases, updated, upgradeCore, upgradeUI, upload, uploadTotal, urlForLatencyTest, urltest, useMobileBottomNav, version, waitingForConnections, warning, xdConfig, xs };
//# sourceMappingURL=en.mjs.map
