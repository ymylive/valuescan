var home = "Главная";
var add = "Добавить";
var collapse = "Свернуть";
var setup = "Настройка";
var setupDescription = "Подключитесь к бэкенду Mihomo, чтобы начать";
var overview = "Обзор";
var proxies = "Прокси";
var proxiesSettings = "Настройки прокси";
var rules = "Правила";
var connections = "Соединения";
var connectionsSettings = "Настройки соединений";
var connectionsDetails = "Детали соединения";
var logs = "Журнал";
var logsSettings = "Настройки журнала";
var config = "Конфигурация";
var upload = "Загрузка";
var download = "Скачивание";
var uploadTotal = "Всего загружено";
var downloadTotal = "Всего скачано";
var activeConnections = "Активные соединения";
var memoryUsage = "Использование памяти";
var flow = "Поток";
var traffic = "Трафик";
var memory = "Память";
var down = "Скач.";
var up = "Загр.";
var proxyProviders = "Провайдеры прокси";
var ruleProviders = "Провайдеры правил";
var search = "Поиск";
var inner = "Внутренний";
var ID = "ID";
var type = "Тип";
var name = "Имя";
var process = "Процесс";
var host = "Хост";
var sniffHost = "Sniff Host";
var chains = "Цепочки";
var connectTime = "Время";
var dlSpeed = "Скор. скач.";
var ulSpeed = "Скор. загр.";
var dl = "Скач.";
var ul = "Загр.";
var sourceIP = "Исходный IP";
var sourcePort = "Исходный порт";
var destination = "Назначение";
var inboundUser = "Входящий пользователь";
var close = "Закрыть";
var pause = "Пауза";
var resume = "Продолжить";
var reset = "Сбросить";
var resetSettings = "Сбросить настройки";
var dnsQuery = "DNS запрос";
var dots = "Точки";
var bar = "Полоса";
var auto = "Авто";
var off = "Выкл";
var proxiesPreviewType = "Тип предпросмотра прокси";
var proxiesDisplayMode = "Режим отображения";
var cardMode = "Карточки";
var listMode = "Список";
var urlForLatencyTest = "URL для теста задержки";
var autoCloseConns = "Автоматически закрывать соединения";
var autoSwitchEndpoint = "Автоматически переключать эндпоинт";
var autoSwitchTheme = "Автоматически переключать тему";
var favDayTheme = "Любимая светлая тема";
var favNightTheme = "Любимая тёмная тема";
var renderInTwoColumns = "Отображать в два столбца";
var updateGEODatabases = "Обновить базы GEO";
var restartCore = "Перезапустить ядро";
var upgradeCore = "Обновить ядро";
var upgradeUI = "Обновить панель";
var proxiesSorting = "Сортировка прокси";
var orderNatural = "Оригинальный порядок из конфига";
var orderLatency_asc = "По задержке (возр.)";
var orderLatency_desc = "По задержке (убыв.)";
var orderName_asc = "По имени (A-Z)";
var orderName_desc = "По имени (Z-A)";
var ms = "мс";
var updated = "Обновлено";
var tableSize = "Размер таблицы";
var logLevel = "Уровень журнала";
var info = "инфо";
var silent = "тихий";
var debug = "отладка";
var warning = "предупреждение";
var error = "ошибка";
var logMaxRows = "Макс. строк журнала";
var xs = "Очень маленький";
var sm = "Маленький";
var md = "Нормальный";
var lg = "Большой";
var switchEndpoint = "Сменить эндпоинт";
var switchLanguage = "Сменить язык";
var switchFont = "Сменить шрифт";
var enableTwemoji = "Включить Twemoji";
var latencyTestTimeoutDuration = "Таймаут теста задержки";
var all = "Все";
var sequence = "Последовательность";
var level = "Уровень";
var payload = "Содержимое";
var details = "Детали";
var endpointURL = "URL эндпоинта";
var secret = "Секрет";
var runningMode = "Режим работы";
var global = "Глобальный";
var rule = "Правило";
var direct = "Прямой";
var reject = "Отклонить";
var rejectdrop = "Сбросить";
var selector = "Селектор";
var urltest = "URL-тест";
var loadbalance = "Баланс";
var fallback = "Резерв";
var relay = "Ретранслятор";
var pass = "Пропустить";
var active = "Активные";
var closed = "Закрытые";
var sort = "Сортировать";
var hideUnavailableProxies = "Скрыть недоступные прокси";
var reloadConfig = "Перезагрузить конфиг";
var flushFakeIP = "Очистить Fake-IP";
var flushDNSCache = "Очистить кэш DNS";
var tagClientSourceIPWithName = "Пометить IP клиента именем";
var tag = "Метка";
var coreConfig = "Конфиг ядра";
var xdConfig = "Конфиг XD";
var version = "Версия";
var expire = "Истекает";
var noExpire = "Без срока";
var allowLan = "Разрешить LAN";
var enableTunDevice = "Включить TUN устройство";
var tunModeStack = "TUN Mode Stack";
var tunDeviceName = "Имя TUN устройства";
var outboundInterfaceName = "Исходящий интерфейс";
var port = "Порт {name}";
var quickFilter = "Быстрый фильтр";
var iconHeight = "Высота иконки";
var iconMarginRight = "Отступ иконки справа";
var dataUsage = "Использование данных";
var clearAll = "Очистить всё";
var confirmClearAll = "Очистить все данные использования?";
var devices = "Устройства";
var timeRange = "Временной диапазон";
var grandTotal = "Общий итог";
var macAddress = "MAC адрес";
var ipAddress = "IP адрес";
var duration = "Длительность";
var total = "Всего";
var actions = "Действия";
var remove = "Удалить";
var noDataUsageYet = "Данных пока нет";
var noData = "Нет данных";
var noRules = "Нет правил";
var noRuleProviders = "Нет провайдеров правил";
var columns = "Столбцы";
var sortBy = "Сортировать по";
var groupBy = "Группировать по";
var rowsPerPage = "Строк на странице";
var ipShort = "IP";
var na = "Н/Д";
var show = "Показать";
var noLatencyHistory = "История задержек отсутствует";
var dataUsageInfo = "Мониторинг данных выполняется на стороне клиента (браузера). При закрытии браузера мониторинг может не работать.";
var basic = "Основные";
var start = "Начало";
var rulePayload = "Правило Payload";
var metadata = "Метаданные";
var network = "Сеть";
var dnsMode = "Режим DNS";
var sourceAndDestination = "Источник и назначение";
var source = "Источник";
var remoteDestination = "Удалённое назначение";
var inbound = "Входящий";
var inboundName = "Имя входящего";
var inboundIP = "IP входящего";
var processName = "Имя процесса";
var processPath = "Путь процесса";
var special = "Специальные";
var specialProxy = "Специальный прокси";
var specialRules = "Специальные правила";
var connectionsChart = "Подключения";
var networkTypes = "Типы сети";
var topProxies = "Топ прокси";
var tcp = "TCP";
var udp = "UDP";
var other = "Другое";
var showTrafficIndicator = "Показать индикатор трафика";
var hideTrafficIndicator = "Скрыть индикатор трафика";
var currentIP = "Текущий IP";
var country = "Страна";
var city = "Город";
var organization = "Организация";
var proxyDetection = "Обнаружение прокси";
var clean = "Чисто";
var networkLatency = "Задержка сети";
var average = "Средняя";
var timeout = "Таймаут";
var networkTopology = "Топология сети";
var client = "Клиент";
var destinations = "Назначения";
var waitingForConnections = "Ожидание соединений...";
var conn = "соед";
var more = "ещё";
var connectedTo = "Подключено к";
var clients = "Клиенты";
var groups = "Группы";
var nodes = "Узлы";
var proxyGroups = "Группы прокси";
var proxyNodes = "Узлы прокси";
var ruleType = "Тип правила";
var useMobileBottomNav = "Нижняя навигация (мобильный)";
const ru = {
	home: home,
	add: add,
	collapse: collapse,
	setup: setup,
	setupDescription: setupDescription,
	overview: overview,
	proxies: proxies,
	proxiesSettings: proxiesSettings,
	rules: rules,
	connections: connections,
	connectionsSettings: connectionsSettings,
	connectionsDetails: connectionsDetails,
	logs: logs,
	logsSettings: logsSettings,
	config: config,
	upload: upload,
	download: download,
	uploadTotal: uploadTotal,
	downloadTotal: downloadTotal,
	activeConnections: activeConnections,
	memoryUsage: memoryUsage,
	flow: flow,
	traffic: traffic,
	memory: memory,
	down: down,
	up: up,
	proxyProviders: proxyProviders,
	ruleProviders: ruleProviders,
	search: search,
	inner: inner,
	ID: ID,
	type: type,
	name: name,
	process: process,
	host: host,
	sniffHost: sniffHost,
	chains: chains,
	connectTime: connectTime,
	dlSpeed: dlSpeed,
	ulSpeed: ulSpeed,
	dl: dl,
	ul: ul,
	sourceIP: sourceIP,
	sourcePort: sourcePort,
	destination: destination,
	inboundUser: inboundUser,
	close: close,
	pause: pause,
	resume: resume,
	reset: reset,
	resetSettings: resetSettings,
	dnsQuery: dnsQuery,
	dots: dots,
	bar: bar,
	auto: auto,
	off: off,
	proxiesPreviewType: proxiesPreviewType,
	proxiesDisplayMode: proxiesDisplayMode,
	cardMode: cardMode,
	listMode: listMode,
	urlForLatencyTest: urlForLatencyTest,
	autoCloseConns: autoCloseConns,
	autoSwitchEndpoint: autoSwitchEndpoint,
	autoSwitchTheme: autoSwitchTheme,
	favDayTheme: favDayTheme,
	favNightTheme: favNightTheme,
	renderInTwoColumns: renderInTwoColumns,
	updateGEODatabases: updateGEODatabases,
	restartCore: restartCore,
	upgradeCore: upgradeCore,
	upgradeUI: upgradeUI,
	proxiesSorting: proxiesSorting,
	orderNatural: orderNatural,
	orderLatency_asc: orderLatency_asc,
	orderLatency_desc: orderLatency_desc,
	orderName_asc: orderName_asc,
	orderName_desc: orderName_desc,
	ms: ms,
	updated: updated,
	tableSize: tableSize,
	logLevel: logLevel,
	info: info,
	silent: silent,
	debug: debug,
	warning: warning,
	error: error,
	logMaxRows: logMaxRows,
	xs: xs,
	sm: sm,
	md: md,
	lg: lg,
	switchEndpoint: switchEndpoint,
	switchLanguage: switchLanguage,
	switchFont: switchFont,
	enableTwemoji: enableTwemoji,
	latencyTestTimeoutDuration: latencyTestTimeoutDuration,
	all: all,
	sequence: sequence,
	level: level,
	payload: payload,
	details: details,
	endpointURL: endpointURL,
	secret: secret,
	runningMode: runningMode,
	global: global,
	rule: rule,
	direct: direct,
	reject: reject,
	rejectdrop: rejectdrop,
	selector: selector,
	urltest: urltest,
	loadbalance: loadbalance,
	fallback: fallback,
	relay: relay,
	pass: pass,
	active: active,
	closed: closed,
	sort: sort,
	hideUnavailableProxies: hideUnavailableProxies,
	reloadConfig: reloadConfig,
	flushFakeIP: flushFakeIP,
	flushDNSCache: flushDNSCache,
	tagClientSourceIPWithName: tagClientSourceIPWithName,
	tag: tag,
	coreConfig: coreConfig,
	xdConfig: xdConfig,
	version: version,
	expire: expire,
	noExpire: noExpire,
	allowLan: allowLan,
	enableTunDevice: enableTunDevice,
	tunModeStack: tunModeStack,
	tunDeviceName: tunDeviceName,
	outboundInterfaceName: outboundInterfaceName,
	port: port,
	quickFilter: quickFilter,
	iconHeight: iconHeight,
	iconMarginRight: iconMarginRight,
	dataUsage: dataUsage,
	clearAll: clearAll,
	confirmClearAll: confirmClearAll,
	devices: devices,
	timeRange: timeRange,
	grandTotal: grandTotal,
	macAddress: macAddress,
	ipAddress: ipAddress,
	duration: duration,
	total: total,
	actions: actions,
	remove: remove,
	noDataUsageYet: noDataUsageYet,
	noData: noData,
	noRules: noRules,
	noRuleProviders: noRuleProviders,
	columns: columns,
	sortBy: sortBy,
	groupBy: groupBy,
	rowsPerPage: rowsPerPage,
	ipShort: ipShort,
	na: na,
	show: show,
	noLatencyHistory: noLatencyHistory,
	dataUsageInfo: dataUsageInfo,
	basic: basic,
	start: start,
	rulePayload: rulePayload,
	metadata: metadata,
	network: network,
	dnsMode: dnsMode,
	sourceAndDestination: sourceAndDestination,
	source: source,
	remoteDestination: remoteDestination,
	inbound: inbound,
	inboundName: inboundName,
	inboundIP: inboundIP,
	processName: processName,
	processPath: processPath,
	special: special,
	specialProxy: specialProxy,
	specialRules: specialRules,
	connectionsChart: connectionsChart,
	networkTypes: networkTypes,
	topProxies: topProxies,
	tcp: tcp,
	udp: udp,
	other: other,
	showTrafficIndicator: showTrafficIndicator,
	hideTrafficIndicator: hideTrafficIndicator,
	currentIP: currentIP,
	country: country,
	city: city,
	organization: organization,
	proxyDetection: proxyDetection,
	clean: clean,
	networkLatency: networkLatency,
	average: average,
	timeout: timeout,
	networkTopology: networkTopology,
	client: client,
	destinations: destinations,
	waitingForConnections: waitingForConnections,
	conn: conn,
	more: more,
	connectedTo: connectedTo,
	clients: clients,
	groups: groups,
	nodes: nodes,
	proxyGroups: proxyGroups,
	proxyNodes: proxyNodes,
	ruleType: ruleType,
	useMobileBottomNav: useMobileBottomNav
};

export { ID, actions, active, activeConnections, add, all, allowLan, auto, autoCloseConns, autoSwitchEndpoint, autoSwitchTheme, average, bar, basic, cardMode, chains, city, clean, clearAll, client, clients, close, closed, collapse, columns, config, confirmClearAll, conn, connectTime, connectedTo, connections, connectionsChart, connectionsDetails, connectionsSettings, coreConfig, country, currentIP, dataUsage, dataUsageInfo, debug, ru as default, destination, destinations, details, devices, direct, dl, dlSpeed, dnsMode, dnsQuery, dots, down, download, downloadTotal, duration, enableTunDevice, enableTwemoji, endpointURL, error, expire, fallback, favDayTheme, favNightTheme, flow, flushDNSCache, flushFakeIP, global, grandTotal, groupBy, groups, hideTrafficIndicator, hideUnavailableProxies, home, host, iconHeight, iconMarginRight, inbound, inboundIP, inboundName, inboundUser, info, inner, ipAddress, ipShort, latencyTestTimeoutDuration, level, lg, listMode, loadbalance, logLevel, logMaxRows, logs, logsSettings, macAddress, md, memory, memoryUsage, metadata, more, ms, na, name, network, networkLatency, networkTopology, networkTypes, noData, noDataUsageYet, noExpire, noLatencyHistory, noRuleProviders, noRules, nodes, off, orderLatency_asc, orderLatency_desc, orderName_asc, orderName_desc, orderNatural, organization, other, outboundInterfaceName, overview, pass, pause, payload, port, process, processName, processPath, proxies, proxiesDisplayMode, proxiesPreviewType, proxiesSettings, proxiesSorting, proxyDetection, proxyGroups, proxyNodes, proxyProviders, quickFilter, reject, rejectdrop, relay, reloadConfig, remoteDestination, remove, renderInTwoColumns, reset, resetSettings, restartCore, resume, rowsPerPage, rule, rulePayload, ruleProviders, ruleType, rules, runningMode, search, secret, selector, sequence, setup, setupDescription, show, showTrafficIndicator, silent, sm, sniffHost, sort, sortBy, source, sourceAndDestination, sourceIP, sourcePort, special, specialProxy, specialRules, start, switchEndpoint, switchFont, switchLanguage, tableSize, tag, tagClientSourceIPWithName, tcp, timeRange, timeout, topProxies, total, traffic, tunDeviceName, tunModeStack, type, udp, ul, ulSpeed, up, updateGEODatabases, updated, upgradeCore, upgradeUI, upload, uploadTotal, urlForLatencyTest, urltest, useMobileBottomNav, version, waitingForConnections, warning, xdConfig, xs };
//# sourceMappingURL=ru.mjs.map
