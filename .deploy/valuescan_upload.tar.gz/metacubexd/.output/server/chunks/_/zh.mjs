var home = "首页";
var add = "添加";
var collapse = "收起";
var setup = "设置";
var setupDescription = "连接到 Mihomo 后端以开始使用";
var overview = "概览";
var proxies = "代理";
var proxiesSettings = "代理设置";
var rules = "规则";
var connections = "连接";
var connectionsSettings = "连接设置";
var connectionsDetails = "连接详情";
var logs = "日志";
var logsSettings = "日志设置";
var config = "配置";
var upload = "上传";
var download = "下载";
var uploadTotal = "上传总量";
var downloadTotal = "下载总量";
var activeConnections = "活动连接";
var memoryUsage = "内存使用情况";
var flow = "流量";
var traffic = "流量";
var memory = "内存";
var down = "下载";
var up = "上传";
var proxyProviders = "代理提供者";
var ruleProviders = "规则提供者";
var search = "搜索";
var inner = "内部";
var ID = "ID";
var type = "类型";
var name = "名字";
var process = "进程";
var host = "主机";
var sniffHost = "嗅探域名";
var chains = "链路";
var connectTime = "连接时间";
var dlSpeed = "下载速度";
var ulSpeed = "上传速度";
var dl = "下载量";
var ul = "上传量";
var sourceIP = "源地址";
var sourcePort = "源端口";
var destination = "目标地址";
var inboundUser = "入站用户";
var close = "关闭";
var pause = "暂停";
var resume = "继续";
var reset = "重置";
var resetSettings = "重置设置";
var dnsQuery = "DNS 查询";
var dots = "点阵";
var bar = "条形";
var auto = "自适应";
var off = "关闭";
var proxiesPreviewType = "节点组预览样式";
var proxiesDisplayMode = "节点显示模式";
var cardMode = "卡片";
var listMode = "列表";
var urlForLatencyTest = "测速链接";
var autoCloseConns = "自动断开连接";
var autoSwitchEndpoint = "自动切换后端";
var autoSwitchTheme = "自动切换主题";
var favDayTheme = "浅色主题偏好";
var favNightTheme = "深色主题偏好";
var renderInTwoColumns = "双列渲染";
var updateGEODatabases = "更新 GEO 数据库";
var restartCore = "重启核心";
var upgradeCore = "更新核心";
var upgradeUI = "更新控制面板";
var proxiesSorting = "节点排序";
var orderNatural = "原配置文件中的排序";
var orderLatency_asc = "按延迟从低到高";
var orderLatency_desc = "按延迟从高到低";
var orderName_asc = "按名称字母排序 (A-Z)";
var orderName_desc = "按名称字母排序 (Z-A)";
var ms = "毫秒";
var updated = "更新于";
var tableSize = "表格大小";
var logLevel = "日志等级";
var info = "信息";
var silent = "静默";
var debug = "调试";
var warning = "警告";
var error = "错误";
var logMaxRows = "日志最大保留行数";
var xs = "超小尺寸";
var sm = "小尺寸";
var md = "正常尺寸";
var lg = "超大尺寸";
var switchEndpoint = "切换后端";
var switchLanguage = "切换语言";
var switchFont = "切换字体";
var enableTwemoji = "启用 Twemoji";
var latencyTestTimeoutDuration = "测速超时时间";
var all = "全部";
var sequence = "序列号";
var level = "等级";
var payload = "内容";
var details = "详情";
var endpointURL = "后端地址";
var secret = "密钥";
var runningMode = "运行模式";
var global = "全局";
var rule = "规则";
var direct = "直连";
var reject = "拒绝";
var rejectdrop = "丢弃";
var selector = "手动选择";
var urltest = "自动选择";
var loadbalance = "负载均衡";
var fallback = "故障转移";
var relay = "链式代理";
var pass = "绕过";
var active = "活动";
var closed = "已关闭";
var sort = "排序";
var hideUnavailableProxies = "隐藏不可用节点";
var reloadConfig = "重载配置";
var flushFakeIP = "清空 Fake-IP";
var flushDNSCache = "清空 DNS 缓存";
var tagClientSourceIPWithName = "为客户端源 IP 地址添加名称标记";
var tag = "标记";
var coreConfig = "核心配置";
var xdConfig = "XD 配置";
var version = "版本";
var expire = "到期时间";
var noExpire = "不限时";
var allowLan = "允许局域网访问";
var enableTunDevice = "开启 TUN 转发";
var tunModeStack = "TUN 模式堆栈";
var tunDeviceName = "TUN 设备名称";
var outboundInterfaceName = "出站接口名称";
var port = "{name} 端口";
var quickFilter = "快速过滤";
var iconHeight = "图标高度";
var iconMarginRight = "图标右边距";
var dataUsage = "数据用量";
var clearAll = "清空全部";
var confirmClearAll = "清除所有数据用量记录？";
var devices = "设备";
var timeRange = "时间范围";
var grandTotal = "总计";
var macAddress = "MAC 地址";
var ipAddress = "IP 地址";
var duration = "持续时长";
var total = "总量";
var actions = "操作";
var remove = "移除";
var noDataUsageYet = "暂无数据用量记录";
var noData = "暂无数据";
var noRules = "暂无规则";
var noRuleProviders = "暂无规则提供者";
var columns = "列";
var sortBy = "排序";
var groupBy = "分组";
var rowsPerPage = "每页行数";
var ipShort = "IP";
var na = "无";
var show = "显示";
var noLatencyHistory = "暂无测速记录";
var dataUsageInfo = "数据用量监控在客户端（浏览器）执行。当浏览器关闭时，监控可能不会运行。";
var basic = "基本信息";
var start = "开始时间";
var rulePayload = "规则载荷";
var metadata = "元数据";
var network = "网络";
var dnsMode = "DNS 模式";
var sourceAndDestination = "源与目标";
var source = "源";
var remoteDestination = "远程目的地";
var inbound = "入站";
var inboundName = "入站名称";
var inboundIP = "入站 IP";
var processName = "进程名称";
var processPath = "进程路径";
var special = "特殊";
var specialProxy = "特殊代理";
var specialRules = "特殊规则";
var connectionsChart = "连接数";
var networkTypes = "网络类型";
var topProxies = "热门代理";
var tcp = "TCP";
var udp = "UDP";
var other = "其他";
var showTrafficIndicator = "显示流量指示器";
var hideTrafficIndicator = "隐藏流量指示器";
var currentIP = "当前 IP";
var country = "国家";
var city = "城市";
var organization = "组织";
var proxyDetection = "代理检测";
var clean = "正常";
var networkLatency = "网络延迟";
var average = "平均";
var timeout = "超时";
var networkTopology = "网络拓扑";
var client = "客户端";
var destinations = "目标";
var waitingForConnections = "等待连接...";
var conn = "连接";
var more = "更多";
var connectedTo = "已连接到";
var clients = "客户端";
var groups = "代理组";
var nodes = "节点";
var proxyGroups = "代理组";
var proxyNodes = "代理节点";
var ruleType = "规则类型";
var useMobileBottomNav = "使用底部导航栏 (移动端)";
const zh = {
	home: home,
	add: add,
	collapse: collapse,
	setup: setup,
	setupDescription: setupDescription,
	overview: overview,
	proxies: proxies,
	proxiesSettings: proxiesSettings,
	rules: rules,
	connections: connections,
	connectionsSettings: connectionsSettings,
	connectionsDetails: connectionsDetails,
	logs: logs,
	logsSettings: logsSettings,
	config: config,
	upload: upload,
	download: download,
	uploadTotal: uploadTotal,
	downloadTotal: downloadTotal,
	activeConnections: activeConnections,
	memoryUsage: memoryUsage,
	flow: flow,
	traffic: traffic,
	memory: memory,
	down: down,
	up: up,
	proxyProviders: proxyProviders,
	ruleProviders: ruleProviders,
	search: search,
	inner: inner,
	ID: ID,
	type: type,
	name: name,
	process: process,
	host: host,
	sniffHost: sniffHost,
	chains: chains,
	connectTime: connectTime,
	dlSpeed: dlSpeed,
	ulSpeed: ulSpeed,
	dl: dl,
	ul: ul,
	sourceIP: sourceIP,
	sourcePort: sourcePort,
	destination: destination,
	inboundUser: inboundUser,
	close: close,
	pause: pause,
	resume: resume,
	reset: reset,
	resetSettings: resetSettings,
	dnsQuery: dnsQuery,
	dots: dots,
	bar: bar,
	auto: auto,
	off: off,
	proxiesPreviewType: proxiesPreviewType,
	proxiesDisplayMode: proxiesDisplayMode,
	cardMode: cardMode,
	listMode: listMode,
	urlForLatencyTest: urlForLatencyTest,
	autoCloseConns: autoCloseConns,
	autoSwitchEndpoint: autoSwitchEndpoint,
	autoSwitchTheme: autoSwitchTheme,
	favDayTheme: favDayTheme,
	favNightTheme: favNightTheme,
	renderInTwoColumns: renderInTwoColumns,
	updateGEODatabases: updateGEODatabases,
	restartCore: restartCore,
	upgradeCore: upgradeCore,
	upgradeUI: upgradeUI,
	proxiesSorting: proxiesSorting,
	orderNatural: orderNatural,
	orderLatency_asc: orderLatency_asc,
	orderLatency_desc: orderLatency_desc,
	orderName_asc: orderName_asc,
	orderName_desc: orderName_desc,
	ms: ms,
	updated: updated,
	tableSize: tableSize,
	logLevel: logLevel,
	info: info,
	silent: silent,
	debug: debug,
	warning: warning,
	error: error,
	logMaxRows: logMaxRows,
	xs: xs,
	sm: sm,
	md: md,
	lg: lg,
	switchEndpoint: switchEndpoint,
	switchLanguage: switchLanguage,
	switchFont: switchFont,
	enableTwemoji: enableTwemoji,
	latencyTestTimeoutDuration: latencyTestTimeoutDuration,
	all: all,
	sequence: sequence,
	level: level,
	payload: payload,
	details: details,
	endpointURL: endpointURL,
	secret: secret,
	runningMode: runningMode,
	global: global,
	rule: rule,
	direct: direct,
	reject: reject,
	rejectdrop: rejectdrop,
	selector: selector,
	urltest: urltest,
	loadbalance: loadbalance,
	fallback: fallback,
	relay: relay,
	pass: pass,
	active: active,
	closed: closed,
	sort: sort,
	hideUnavailableProxies: hideUnavailableProxies,
	reloadConfig: reloadConfig,
	flushFakeIP: flushFakeIP,
	flushDNSCache: flushDNSCache,
	tagClientSourceIPWithName: tagClientSourceIPWithName,
	tag: tag,
	coreConfig: coreConfig,
	xdConfig: xdConfig,
	version: version,
	expire: expire,
	noExpire: noExpire,
	allowLan: allowLan,
	enableTunDevice: enableTunDevice,
	tunModeStack: tunModeStack,
	tunDeviceName: tunDeviceName,
	outboundInterfaceName: outboundInterfaceName,
	port: port,
	quickFilter: quickFilter,
	iconHeight: iconHeight,
	iconMarginRight: iconMarginRight,
	dataUsage: dataUsage,
	clearAll: clearAll,
	confirmClearAll: confirmClearAll,
	devices: devices,
	timeRange: timeRange,
	grandTotal: grandTotal,
	macAddress: macAddress,
	ipAddress: ipAddress,
	duration: duration,
	total: total,
	actions: actions,
	remove: remove,
	noDataUsageYet: noDataUsageYet,
	noData: noData,
	noRules: noRules,
	noRuleProviders: noRuleProviders,
	columns: columns,
	sortBy: sortBy,
	groupBy: groupBy,
	rowsPerPage: rowsPerPage,
	ipShort: ipShort,
	na: na,
	show: show,
	noLatencyHistory: noLatencyHistory,
	dataUsageInfo: dataUsageInfo,
	basic: basic,
	start: start,
	rulePayload: rulePayload,
	metadata: metadata,
	network: network,
	dnsMode: dnsMode,
	sourceAndDestination: sourceAndDestination,
	source: source,
	remoteDestination: remoteDestination,
	inbound: inbound,
	inboundName: inboundName,
	inboundIP: inboundIP,
	processName: processName,
	processPath: processPath,
	special: special,
	specialProxy: specialProxy,
	specialRules: specialRules,
	connectionsChart: connectionsChart,
	networkTypes: networkTypes,
	topProxies: topProxies,
	tcp: tcp,
	udp: udp,
	other: other,
	showTrafficIndicator: showTrafficIndicator,
	hideTrafficIndicator: hideTrafficIndicator,
	currentIP: currentIP,
	country: country,
	city: city,
	organization: organization,
	proxyDetection: proxyDetection,
	clean: clean,
	networkLatency: networkLatency,
	average: average,
	timeout: timeout,
	networkTopology: networkTopology,
	client: client,
	destinations: destinations,
	waitingForConnections: waitingForConnections,
	conn: conn,
	more: more,
	connectedTo: connectedTo,
	clients: clients,
	groups: groups,
	nodes: nodes,
	proxyGroups: proxyGroups,
	proxyNodes: proxyNodes,
	ruleType: ruleType,
	useMobileBottomNav: useMobileBottomNav
};

export { ID, actions, active, activeConnections, add, all, allowLan, auto, autoCloseConns, autoSwitchEndpoint, autoSwitchTheme, average, bar, basic, cardMode, chains, city, clean, clearAll, client, clients, close, closed, collapse, columns, config, confirmClearAll, conn, connectTime, connectedTo, connections, connectionsChart, connectionsDetails, connectionsSettings, coreConfig, country, currentIP, dataUsage, dataUsageInfo, debug, zh as default, destination, destinations, details, devices, direct, dl, dlSpeed, dnsMode, dnsQuery, dots, down, download, downloadTotal, duration, enableTunDevice, enableTwemoji, endpointURL, error, expire, fallback, favDayTheme, favNightTheme, flow, flushDNSCache, flushFakeIP, global, grandTotal, groupBy, groups, hideTrafficIndicator, hideUnavailableProxies, home, host, iconHeight, iconMarginRight, inbound, inboundIP, inboundName, inboundUser, info, inner, ipAddress, ipShort, latencyTestTimeoutDuration, level, lg, listMode, loadbalance, logLevel, logMaxRows, logs, logsSettings, macAddress, md, memory, memoryUsage, metadata, more, ms, na, name, network, networkLatency, networkTopology, networkTypes, noData, noDataUsageYet, noExpire, noLatencyHistory, noRuleProviders, noRules, nodes, off, orderLatency_asc, orderLatency_desc, orderName_asc, orderName_desc, orderNatural, organization, other, outboundInterfaceName, overview, pass, pause, payload, port, process, processName, processPath, proxies, proxiesDisplayMode, proxiesPreviewType, proxiesSettings, proxiesSorting, proxyDetection, proxyGroups, proxyNodes, proxyProviders, quickFilter, reject, rejectdrop, relay, reloadConfig, remoteDestination, remove, renderInTwoColumns, reset, resetSettings, restartCore, resume, rowsPerPage, rule, rulePayload, ruleProviders, ruleType, rules, runningMode, search, secret, selector, sequence, setup, setupDescription, show, showTrafficIndicator, silent, sm, sniffHost, sort, sortBy, source, sourceAndDestination, sourceIP, sourcePort, special, specialProxy, specialRules, start, switchEndpoint, switchFont, switchLanguage, tableSize, tag, tagClientSourceIPWithName, tcp, timeRange, timeout, topProxies, total, traffic, tunDeviceName, tunModeStack, type, udp, ul, ulSpeed, up, updateGEODatabases, updated, upgradeCore, upgradeUI, upload, uploadTotal, urlForLatencyTest, urltest, useMobileBottomNav, version, waitingForConnections, warning, xdConfig, xs };
//# sourceMappingURL=zh.mjs.map
