window.__METACUBEXD_CONFIG__ = {
  defaultBackendURL: 'https://cornna.abrdns.com/clash-api',
}
