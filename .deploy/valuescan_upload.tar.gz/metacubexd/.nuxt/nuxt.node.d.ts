/// <reference types="@vueuse/nuxt" />
/// <reference types="@pinia/nuxt" />
/// <reference types="@nuxtjs/i18n" />
/// <reference types="@nuxt/fonts" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="@nuxt/devtools" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference types="../node_modules/.pnpm/@nuxt+vite-builder@4.2.2_@t_0f116b8c7ebfe0bd753e46656f710848/node_modules/@nuxt/vite-builder/dist/index.mjs" />
/// <reference types="E:/project/valuescan/metacubexd/node_modules/.pnpm/@nuxt+nitro-server@4.2.2_db_3f856e7e0c00b80eb875f85cb1b8b446/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
