
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T

interface _GlobalComponents {
  'Button': typeof import("../../components/Button.vue").default
  'Changelog': typeof import("../../components/Changelog.vue").default
  'Collapse': typeof import("../../components/Collapse.vue").default
  'ConfigTitle': typeof import("../../components/ConfigTitle.vue").default
  'DataTable': typeof import("../../components/DataTable.vue").default
  'DataUsageTable': typeof import("../../components/DataUsageTable.vue").default
  'GlobalTrafficIndicator': typeof import("../../components/GlobalTrafficIndicator.vue").default
  'HighchartsAutoSize': typeof import("../../components/HighchartsAutoSize.vue").default
  'IPInfoCard': typeof import("../../components/IPInfoCard.vue").default
  'LangSwitcher': typeof import("../../components/LangSwitcher.vue").default
  'Latency': typeof import("../../components/Latency.vue").default
  'LatencyCard': typeof import("../../components/LatencyCard.vue").default
  'LogoText': typeof import("../../components/LogoText.vue").default
  'MobileBottomNav': typeof import("../../components/MobileBottomNav.vue").default
  'Modal': typeof import("../../components/Modal.vue").default
  'NetworkTopology': typeof import("../../components/NetworkTopology.vue").default
  'ProtectedResources': typeof import("../../components/ProtectedResources.vue").default
  'ProxiesRenderWrapper': typeof import("../../components/ProxiesRenderWrapper.vue").default
  'ProxyNodeCard': typeof import("../../components/ProxyNodeCard.vue").default
  'ProxyNodeListItem': typeof import("../../components/ProxyNodeListItem.vue").default
  'ProxyNodePreview': typeof import("../../components/ProxyNodePreview.vue").default
  'ProxyPreviewBar': typeof import("../../components/ProxyPreviewBar.vue").default
  'ProxyPreviewDots': typeof import("../../components/ProxyPreviewDots.vue").default
  'RealtimeLineChart': typeof import("../../components/RealtimeLineChart.vue").default
  'Sidebar': typeof import("../../components/Sidebar.vue").default
  'SubscriptionInfo': typeof import("../../components/SubscriptionInfo.vue").default
  'ThemeSelector': typeof import("../../components/ThemeSelector.vue").default
  'ThemeSwitcher': typeof import("../../components/ThemeSwitcher.vue").default
  'TrafficWidget': typeof import("../../components/TrafficWidget.vue").default
  'Versions': typeof import("../../components/Versions.vue").default
  'ConnectionDetailsModal': typeof import("../../components/connections/ConnectionDetailsModal.vue").default
  'ConnectionsPagination': typeof import("../../components/connections/ConnectionsPagination.vue").default
  'ConnectionsSettingsModal': typeof import("../../components/connections/ConnectionsSettingsModal.vue").default
  'ConnectionsTable': typeof import("../../components/connections/ConnectionsTable.vue").default
  'ConnectionsToolbar': typeof import("../../components/connections/ConnectionsToolbar.vue").default
  'Connections': typeof import("../../components/connections/index").default
  'NuxtWelcome': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/welcome.vue").default
  'NuxtLayout': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-layout").default
  'NuxtErrorBoundary': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default
  'ClientOnly': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/client-only").default
  'DevOnly': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/dev-only").default
  'ServerPlaceholder': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/server-placeholder").default
  'NuxtLink': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-link").default
  'NuxtLoadingIndicator': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default
  'NuxtTime': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-time.vue").default
  'NuxtRouteAnnouncer': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default
  'NuxtImg': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-stubs").NuxtImg
  'NuxtPicture': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-stubs").NuxtPicture
  'NuxtLinkLocale': typeof import("../../node_modules/.pnpm/@nuxtjs+i18n@10.2.1_@vue+co_aafeaefb25751fbe65dd2708ba9f59c7/node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale").default
  'SwitchLocalePathLink': typeof import("../../node_modules/.pnpm/@nuxtjs+i18n@10.2.1_@vue+co_aafeaefb25751fbe65dd2708ba9f59c7/node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink").default
  'NuxtPage': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/pages/runtime/page").default
  'NoScript': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").NoScript
  'Link': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Link
  'Base': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Base
  'Title': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Title
  'Meta': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Meta
  'Style': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Style
  'Head': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Head
  'Html': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Html
  'Body': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Body
  'NuxtIsland': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-island").default
  'LazyButton': LazyComponent<typeof import("../../components/Button.vue").default>
  'LazyChangelog': LazyComponent<typeof import("../../components/Changelog.vue").default>
  'LazyCollapse': LazyComponent<typeof import("../../components/Collapse.vue").default>
  'LazyConfigTitle': LazyComponent<typeof import("../../components/ConfigTitle.vue").default>
  'LazyDataTable': LazyComponent<typeof import("../../components/DataTable.vue").default>
  'LazyDataUsageTable': LazyComponent<typeof import("../../components/DataUsageTable.vue").default>
  'LazyGlobalTrafficIndicator': LazyComponent<typeof import("../../components/GlobalTrafficIndicator.vue").default>
  'LazyHighchartsAutoSize': LazyComponent<typeof import("../../components/HighchartsAutoSize.vue").default>
  'LazyIPInfoCard': LazyComponent<typeof import("../../components/IPInfoCard.vue").default>
  'LazyLangSwitcher': LazyComponent<typeof import("../../components/LangSwitcher.vue").default>
  'LazyLatency': LazyComponent<typeof import("../../components/Latency.vue").default>
  'LazyLatencyCard': LazyComponent<typeof import("../../components/LatencyCard.vue").default>
  'LazyLogoText': LazyComponent<typeof import("../../components/LogoText.vue").default>
  'LazyMobileBottomNav': LazyComponent<typeof import("../../components/MobileBottomNav.vue").default>
  'LazyModal': LazyComponent<typeof import("../../components/Modal.vue").default>
  'LazyNetworkTopology': LazyComponent<typeof import("../../components/NetworkTopology.vue").default>
  'LazyProtectedResources': LazyComponent<typeof import("../../components/ProtectedResources.vue").default>
  'LazyProxiesRenderWrapper': LazyComponent<typeof import("../../components/ProxiesRenderWrapper.vue").default>
  'LazyProxyNodeCard': LazyComponent<typeof import("../../components/ProxyNodeCard.vue").default>
  'LazyProxyNodeListItem': LazyComponent<typeof import("../../components/ProxyNodeListItem.vue").default>
  'LazyProxyNodePreview': LazyComponent<typeof import("../../components/ProxyNodePreview.vue").default>
  'LazyProxyPreviewBar': LazyComponent<typeof import("../../components/ProxyPreviewBar.vue").default>
  'LazyProxyPreviewDots': LazyComponent<typeof import("../../components/ProxyPreviewDots.vue").default>
  'LazyRealtimeLineChart': LazyComponent<typeof import("../../components/RealtimeLineChart.vue").default>
  'LazySidebar': LazyComponent<typeof import("../../components/Sidebar.vue").default>
  'LazySubscriptionInfo': LazyComponent<typeof import("../../components/SubscriptionInfo.vue").default>
  'LazyThemeSelector': LazyComponent<typeof import("../../components/ThemeSelector.vue").default>
  'LazyThemeSwitcher': LazyComponent<typeof import("../../components/ThemeSwitcher.vue").default>
  'LazyTrafficWidget': LazyComponent<typeof import("../../components/TrafficWidget.vue").default>
  'LazyVersions': LazyComponent<typeof import("../../components/Versions.vue").default>
  'LazyConnectionDetailsModal': LazyComponent<typeof import("../../components/connections/ConnectionDetailsModal.vue").default>
  'LazyConnectionsPagination': LazyComponent<typeof import("../../components/connections/ConnectionsPagination.vue").default>
  'LazyConnectionsSettingsModal': LazyComponent<typeof import("../../components/connections/ConnectionsSettingsModal.vue").default>
  'LazyConnectionsTable': LazyComponent<typeof import("../../components/connections/ConnectionsTable.vue").default>
  'LazyConnectionsToolbar': LazyComponent<typeof import("../../components/connections/ConnectionsToolbar.vue").default>
  'LazyConnections': LazyComponent<typeof import("../../components/connections/index").default>
  'LazyNuxtWelcome': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/welcome.vue").default>
  'LazyNuxtLayout': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-layout").default>
  'LazyNuxtErrorBoundary': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default>
  'LazyClientOnly': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/client-only").default>
  'LazyDevOnly': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/dev-only").default>
  'LazyServerPlaceholder': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/server-placeholder").default>
  'LazyNuxtLink': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-link").default>
  'LazyNuxtLoadingIndicator': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default>
  'LazyNuxtTime': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-time.vue").default>
  'LazyNuxtRouteAnnouncer': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default>
  'LazyNuxtImg': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-stubs").NuxtImg>
  'LazyNuxtPicture': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-stubs").NuxtPicture>
  'LazyNuxtLinkLocale': LazyComponent<typeof import("../../node_modules/.pnpm/@nuxtjs+i18n@10.2.1_@vue+co_aafeaefb25751fbe65dd2708ba9f59c7/node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale").default>
  'LazySwitchLocalePathLink': LazyComponent<typeof import("../../node_modules/.pnpm/@nuxtjs+i18n@10.2.1_@vue+co_aafeaefb25751fbe65dd2708ba9f59c7/node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink").default>
  'LazyNuxtPage': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/pages/runtime/page").default>
  'LazyNoScript': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").NoScript>
  'LazyLink': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Link>
  'LazyBase': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Base>
  'LazyTitle': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Title>
  'LazyMeta': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Meta>
  'LazyStyle': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Style>
  'LazyHead': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Head>
  'LazyHtml': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Html>
  'LazyBody': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Body>
  'LazyNuxtIsland': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-island").default>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export {}
