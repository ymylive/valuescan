
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T


export const Button: typeof import("../components/Button.vue").default
export const Changelog: typeof import("../components/Changelog.vue").default
export const Collapse: typeof import("../components/Collapse.vue").default
export const ConfigTitle: typeof import("../components/ConfigTitle.vue").default
export const DataTable: typeof import("../components/DataTable.vue").default
export const DataUsageTable: typeof import("../components/DataUsageTable.vue").default
export const GlobalTrafficIndicator: typeof import("../components/GlobalTrafficIndicator.vue").default
export const HighchartsAutoSize: typeof import("../components/HighchartsAutoSize.vue").default
export const IPInfoCard: typeof import("../components/IPInfoCard.vue").default
export const LangSwitcher: typeof import("../components/LangSwitcher.vue").default
export const Latency: typeof import("../components/Latency.vue").default
export const LatencyCard: typeof import("../components/LatencyCard.vue").default
export const LogoText: typeof import("../components/LogoText.vue").default
export const MobileBottomNav: typeof import("../components/MobileBottomNav.vue").default
export const Modal: typeof import("../components/Modal.vue").default
export const NetworkTopology: typeof import("../components/NetworkTopology.vue").default
export const ProtectedResources: typeof import("../components/ProtectedResources.vue").default
export const ProxiesRenderWrapper: typeof import("../components/ProxiesRenderWrapper.vue").default
export const ProxyNodeCard: typeof import("../components/ProxyNodeCard.vue").default
export const ProxyNodeListItem: typeof import("../components/ProxyNodeListItem.vue").default
export const ProxyNodePreview: typeof import("../components/ProxyNodePreview.vue").default
export const ProxyPreviewBar: typeof import("../components/ProxyPreviewBar.vue").default
export const ProxyPreviewDots: typeof import("../components/ProxyPreviewDots.vue").default
export const RealtimeLineChart: typeof import("../components/RealtimeLineChart.vue").default
export const Sidebar: typeof import("../components/Sidebar.vue").default
export const SubscriptionInfo: typeof import("../components/SubscriptionInfo.vue").default
export const ThemeSelector: typeof import("../components/ThemeSelector.vue").default
export const ThemeSwitcher: typeof import("../components/ThemeSwitcher.vue").default
export const TrafficWidget: typeof import("../components/TrafficWidget.vue").default
export const Versions: typeof import("../components/Versions.vue").default
export const ConnectionDetailsModal: typeof import("../components/connections/ConnectionDetailsModal.vue").default
export const ConnectionsPagination: typeof import("../components/connections/ConnectionsPagination.vue").default
export const ConnectionsSettingsModal: typeof import("../components/connections/ConnectionsSettingsModal.vue").default
export const ConnectionsTable: typeof import("../components/connections/ConnectionsTable.vue").default
export const ConnectionsToolbar: typeof import("../components/connections/ConnectionsToolbar.vue").default
export const Connections: typeof import("../components/connections/index").default
export const NuxtWelcome: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/welcome.vue").default
export const NuxtLayout: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-layout").default
export const NuxtErrorBoundary: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default
export const ClientOnly: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/client-only").default
export const DevOnly: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/dev-only").default
export const ServerPlaceholder: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/server-placeholder").default
export const NuxtLink: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-link").default
export const NuxtLoadingIndicator: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default
export const NuxtTime: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-time.vue").default
export const NuxtRouteAnnouncer: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default
export const NuxtImg: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-stubs").NuxtImg
export const NuxtPicture: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-stubs").NuxtPicture
export const NuxtLinkLocale: typeof import("../node_modules/.pnpm/@nuxtjs+i18n@10.2.1_@vue+co_aafeaefb25751fbe65dd2708ba9f59c7/node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale").default
export const SwitchLocalePathLink: typeof import("../node_modules/.pnpm/@nuxtjs+i18n@10.2.1_@vue+co_aafeaefb25751fbe65dd2708ba9f59c7/node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink").default
export const NuxtPage: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/pages/runtime/page").default
export const NoScript: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").NoScript
export const Link: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Link
export const Base: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Base
export const Title: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Title
export const Meta: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Meta
export const Style: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Style
export const Head: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Head
export const Html: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Html
export const Body: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Body
export const NuxtIsland: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-island").default
export const LazyButton: LazyComponent<typeof import("../components/Button.vue").default>
export const LazyChangelog: LazyComponent<typeof import("../components/Changelog.vue").default>
export const LazyCollapse: LazyComponent<typeof import("../components/Collapse.vue").default>
export const LazyConfigTitle: LazyComponent<typeof import("../components/ConfigTitle.vue").default>
export const LazyDataTable: LazyComponent<typeof import("../components/DataTable.vue").default>
export const LazyDataUsageTable: LazyComponent<typeof import("../components/DataUsageTable.vue").default>
export const LazyGlobalTrafficIndicator: LazyComponent<typeof import("../components/GlobalTrafficIndicator.vue").default>
export const LazyHighchartsAutoSize: LazyComponent<typeof import("../components/HighchartsAutoSize.vue").default>
export const LazyIPInfoCard: LazyComponent<typeof import("../components/IPInfoCard.vue").default>
export const LazyLangSwitcher: LazyComponent<typeof import("../components/LangSwitcher.vue").default>
export const LazyLatency: LazyComponent<typeof import("../components/Latency.vue").default>
export const LazyLatencyCard: LazyComponent<typeof import("../components/LatencyCard.vue").default>
export const LazyLogoText: LazyComponent<typeof import("../components/LogoText.vue").default>
export const LazyMobileBottomNav: LazyComponent<typeof import("../components/MobileBottomNav.vue").default>
export const LazyModal: LazyComponent<typeof import("../components/Modal.vue").default>
export const LazyNetworkTopology: LazyComponent<typeof import("../components/NetworkTopology.vue").default>
export const LazyProtectedResources: LazyComponent<typeof import("../components/ProtectedResources.vue").default>
export const LazyProxiesRenderWrapper: LazyComponent<typeof import("../components/ProxiesRenderWrapper.vue").default>
export const LazyProxyNodeCard: LazyComponent<typeof import("../components/ProxyNodeCard.vue").default>
export const LazyProxyNodeListItem: LazyComponent<typeof import("../components/ProxyNodeListItem.vue").default>
export const LazyProxyNodePreview: LazyComponent<typeof import("../components/ProxyNodePreview.vue").default>
export const LazyProxyPreviewBar: LazyComponent<typeof import("../components/ProxyPreviewBar.vue").default>
export const LazyProxyPreviewDots: LazyComponent<typeof import("../components/ProxyPreviewDots.vue").default>
export const LazyRealtimeLineChart: LazyComponent<typeof import("../components/RealtimeLineChart.vue").default>
export const LazySidebar: LazyComponent<typeof import("../components/Sidebar.vue").default>
export const LazySubscriptionInfo: LazyComponent<typeof import("../components/SubscriptionInfo.vue").default>
export const LazyThemeSelector: LazyComponent<typeof import("../components/ThemeSelector.vue").default>
export const LazyThemeSwitcher: LazyComponent<typeof import("../components/ThemeSwitcher.vue").default>
export const LazyTrafficWidget: LazyComponent<typeof import("../components/TrafficWidget.vue").default>
export const LazyVersions: LazyComponent<typeof import("../components/Versions.vue").default>
export const LazyConnectionDetailsModal: LazyComponent<typeof import("../components/connections/ConnectionDetailsModal.vue").default>
export const LazyConnectionsPagination: LazyComponent<typeof import("../components/connections/ConnectionsPagination.vue").default>
export const LazyConnectionsSettingsModal: LazyComponent<typeof import("../components/connections/ConnectionsSettingsModal.vue").default>
export const LazyConnectionsTable: LazyComponent<typeof import("../components/connections/ConnectionsTable.vue").default>
export const LazyConnectionsToolbar: LazyComponent<typeof import("../components/connections/ConnectionsToolbar.vue").default>
export const LazyConnections: LazyComponent<typeof import("../components/connections/index").default>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/welcome.vue").default>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-layout").default>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/client-only").default>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/dev-only").default>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/server-placeholder").default>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-link").default>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-time.vue").default>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-stubs").NuxtImg>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-stubs").NuxtPicture>
export const LazyNuxtLinkLocale: LazyComponent<typeof import("../node_modules/.pnpm/@nuxtjs+i18n@10.2.1_@vue+co_aafeaefb25751fbe65dd2708ba9f59c7/node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale").default>
export const LazySwitchLocalePathLink: LazyComponent<typeof import("../node_modules/.pnpm/@nuxtjs+i18n@10.2.1_@vue+co_aafeaefb25751fbe65dd2708ba9f59c7/node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink").default>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/pages/runtime/page").default>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").NoScript>
export const LazyLink: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Link>
export const LazyBase: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Base>
export const LazyTitle: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Title>
export const LazyMeta: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Meta>
export const LazyStyle: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Style>
export const LazyHead: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Head>
export const LazyHtml: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Html>
export const LazyBody: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/head/runtime/components").Body>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@_0358ea7b62cff437d15e412b6b57b4ae/node_modules/nuxt/dist/app/components/nuxt-island").default>

export const componentNames: string[]
