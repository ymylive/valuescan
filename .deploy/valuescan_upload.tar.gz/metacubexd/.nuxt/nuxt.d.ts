/// <reference types="@vueuse/nuxt" />
/// <reference types="@pinia/nuxt" />
/// <reference types="@nuxtjs/i18n" />
/// <reference types="@nuxt/fonts" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="@nuxt/devtools" />
/// <reference path="types/builder-env.d.ts" />
/// <reference path="types/plugins.d.ts" />
/// <reference path="types/build.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference types="nuxt/app" />
/// <reference types="E:/project/valuescan/metacubexd/node_modules/.pnpm/@nuxt+nitro-server@4.2.2_db_3f856e7e0c00b80eb875f85cb1b8b446/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference types="@pinia/nuxt" />
/// <reference path="types/i18n-plugin.d.ts" />
/// <reference types="vue-router" />
/// <reference path="types/middleware.d.ts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="types/layouts.d.ts" />
/// <reference path="types/components.d.ts" />
/// <reference path="imports.d.ts" />
/// <reference path="types/imports.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />
/// <reference path="types/nitro.d.ts" />

export {}
