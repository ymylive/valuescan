import os


def _env_bool(key: str, default: bool) -> bool:
    raw = os.getenv(key)
    if raw is None or raw == "":
        return default
    return str(raw).strip().lower() in ("1", "true", "yes", "on")


def _env_str(*keys: str, default: str = "") -> str:
    for key in keys:
        val = os.getenv(key)
        if val:
            return str(val)
    return default


def _env_int(*keys: str, default: int) -> int:
    raw = _env_str(*keys, default=str(default))
    try:
        return int(raw)
    except Exception:
        return default


LOG_LEVEL = _env_str("NOFX_LOG_LEVEL", "LOG_LEVEL", default="INFO")
LOG_TO_FILE = _env_bool("NOFX_LOG_TO_FILE", _env_bool("LOG_TO_FILE", True))
LOG_FILE = _env_str("NOFX_LOG_FILE", "LOG_FILE", default="data/signal_monitor.log")
LOG_MAX_SIZE = _env_int("NOFX_LOG_MAX_SIZE", "LOG_MAX_SIZE", default=10 * 1024 * 1024)
LOG_BACKUP_COUNT = _env_int("NOFX_LOG_BACKUP_COUNT", "LOG_BACKUP_COUNT", default=3)
LOG_FORMAT = _env_str("NOFX_LOG_FORMAT", "LOG_FORMAT", default="%(asctime)s [%(levelname)s] %(message)s")
LOG_DATE_FORMAT = _env_str("NOFX_LOG_DATE_FORMAT", "LOG_DATE_FORMAT", default="%Y-%m-%d %H:%M:%S")

LANGUAGE = _env_str("NOFX_LANGUAGE", "LANGUAGE", default="zh")

ENABLE_TELEGRAM = _env_bool("NOFX_ENABLE_TELEGRAM", _env_bool("ENABLE_TELEGRAM", True))
TELEGRAM_BOT_TOKEN = _env_str("NOFX_TELEGRAM_BOT_TOKEN", "TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = _env_str("NOFX_TELEGRAM_CHAT_ID", "TELEGRAM_CHAT_ID")
SEND_TG_IN_MODE_1 = _env_bool("NOFX_SEND_TG_IN_MODE_1", _env_bool("SEND_TG_IN_MODE_1", True))

CHART_IMG_API_KEY = _env_str("NOFX_CHART_IMG_API_KEY", "CHART_IMG_API_KEY")
CHART_IMG_LAYOUT_ID = _env_str("NOFX_CHART_IMG_LAYOUT_ID", "CHART_IMG_LAYOUT_ID")
CHART_IMG_WIDTH = int(_env_str("NOFX_CHART_IMG_WIDTH", "CHART_IMG_WIDTH", default="800"))
CHART_IMG_HEIGHT = int(_env_str("NOFX_CHART_IMG_HEIGHT", "CHART_IMG_HEIGHT", default="600"))
CHART_IMG_TIMEOUT = int(_env_str("NOFX_CHART_IMG_TIMEOUT", "CHART_IMG_TIMEOUT", default="90"))

ENABLE_PRO_CHART = _env_bool("NOFX_ENABLE_PRO_CHART", _env_bool("ENABLE_PRO_CHART", True))

ENABLE_AI_KEY_LEVELS = _env_bool("NOFX_ENABLE_AI_KEY_LEVELS", _env_bool("ENABLE_AI_KEY_LEVELS", False))
ENABLE_AI_OVERLAYS = _env_bool("NOFX_ENABLE_AI_OVERLAYS", _env_bool("ENABLE_AI_OVERLAYS", False))
ENABLE_AI_SIGNAL_ANALYSIS = _env_bool("NOFX_ENABLE_AI_SIGNAL_ANALYSIS", _env_bool("ENABLE_AI_SIGNAL_ANALYSIS", True))

REALTIME_MARKET_ENABLED = False
if os.getenv("NOFX_REALTIME_MARKET_ENABLED") not in (None, ""):
    REALTIME_MARKET_ENABLED = _env_bool(
        "NOFX_REALTIME_MARKET_ENABLED",
        REALTIME_MARKET_ENABLED,
    )

HTTP_PROXY = _env_str("NOFX_HTTP_PROXY", default="")
SOCKS5_PROXY = _env_str("NOFX_SOCKS5_PROXY", default="")

AI_SIGNAL_INTERVAL_MINUTES = int(_env_str("NOFX_AI_SIGNAL_INTERVAL_MINUTES", "AI_SIGNAL_INTERVAL_MINUTES", default="30"))
AI_SIGNAL_SYMBOLS = [s.strip().upper() for s in _env_str("NOFX_AI_SIGNAL_SYMBOLS", "AI_SIGNAL_SYMBOLS", default="BTC,ETH,BNB,SOL,XAUUSDT,XAGUSDT").split(",") if s.strip()]
AI_SIGNAL_SYMBOL_DELAY = int(_env_str("NOFX_AI_SIGNAL_SYMBOL_DELAY", "AI_SIGNAL_SYMBOL_DELAY", default="2"))
AI_SIGNAL_DEDUP_SECONDS = int(_env_str("NOFX_AI_SIGNAL_DEDUP_SECONDS", "AI_SIGNAL_DEDUP_SECONDS", default="120"))

COINMARKETCAP_API_KEY = _env_str("COINMARKETCAP_API_KEY")
CRYPTOCOMPARE_API_KEY = _env_str("CRYPTOCOMPARE_API_KEY")
COINGECKO_API_KEY = _env_str("COINGECKO_API_KEY")

# 交易员评测配置
ENABLE_TRADER_EVALUATION = _env_bool("NOFX_ENABLE_TRADER_EVALUATION", True)
TRADER_EVAL_CACHE_TTL = int(_env_str("NOFX_TRADER_EVAL_CACHE_TTL", default="300"))
TRADER_EVAL_RATE_LIMIT = int(_env_str("NOFX_TRADER_EVAL_RATE_LIMIT", default="10"))
TELEGRAM_BOT_MODE = _env_bool("NOFX_TELEGRAM_BOT_MODE", True)
TELEGRAM_ALLOWED_USERS = [int(x) for x in _env_str("NOFX_TELEGRAM_ALLOWED_USERS", default="").split(",") if x.strip().isdigit()]
