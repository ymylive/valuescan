"""
日志工具模块
提供统一的日志记录功能，支持控制台和文件输出
"""

import logging
import sys
import io
from pathlib import Path
from logging.handlers import RotatingFileHandler
try:
    from signal_monitor.config import (
        LOG_LEVEL,
        LOG_TO_FILE,
        LOG_FILE,
        LOG_MAX_SIZE,
        LOG_BACKUP_COUNT,
        LOG_FORMAT,
        LOG_DATE_FORMAT,
    )
except Exception:
    from config import (
        LOG_LEVEL,
        LOG_TO_FILE,
        LOG_FILE,
        LOG_MAX_SIZE,
        LOG_BACKUP_COUNT,
        LOG_FORMAT,
        LOG_DATE_FORMAT,
    )


def setup_logger(name='signal_monitor'):
    """
    配置并返回logger实例
    
    Args:
        name: logger名称
    
    Returns:
        logging.Logger: 配置好的logger实例
    """
    logger = logging.getLogger(name)
    
    # 如果logger已经有处理器，说明已经配置过了，直接返回
    if logger.handlers:
        return logger
    
    # 设置日志级别
    logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))
    
    # 创建格式化器
    formatter = logging.Formatter(LOG_FORMAT, LOG_DATE_FORMAT)
    
    # Ensure stdout uses UTF-8 to avoid Windows GBK encode errors.
    try:
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        else:
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    except Exception:
        pass

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # 文件处理器 - 可选
    if LOG_TO_FILE:
        try:
            log_path = Path(LOG_FILE)
            if log_path.parent and not log_path.parent.exists():
                log_path.parent.mkdir(parents=True, exist_ok=True)
            file_handler = RotatingFileHandler(
                str(log_path),
                maxBytes=LOG_MAX_SIZE,
                backupCount=LOG_BACKUP_COUNT,
                encoding='utf-8'
            )
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        except Exception as e:
            logger.warning(f"无法创建日志文件: {e}")
    
    # 防止日志传播到根logger
    logger.propagate = False
    
    return logger


# 创建默认的logger实例
logger = setup_logger()
