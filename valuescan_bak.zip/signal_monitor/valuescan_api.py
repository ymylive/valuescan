#!/usr/bin/env python3
"""
ValueScan API helpers for dense area main force levels.
"""

import json
import os
import time
import ssl
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests
import socket
from requests.adapters import HTTPAdapter
from urllib3.poolmanager import PoolManager

try:
    from .logger import logger
except Exception:
    try:
        from logger import logger
    except Exception:
        logger = None  # type: ignore[assignment]


BASE_URL = os.getenv("VALUESCAN_API_BASE", "https://api.valuescan.io").rstrip("/")
DEFAULT_LOCALSTORAGE = Path(
    os.getenv("VALUESCAN_TOKEN_FILE") or (Path(__file__).parent / "valuescan_localstorage.json")
)
DEFAULT_ORIGIN = "https://www.valuescan.io"
ACCESS_TICKET_FALLBACK = (os.getenv("VALUESCAN_ACCESS_TICKET_FALLBACK") or "LNe1VTyHk0bij3cyWB2gxg==").strip()

_CACHE_TTL_SEC = 120
DEFAULT_DENSE_DAYS = int(os.getenv("VALUESCAN_KEY_LEVELS_DAYS", "15") or 15)
_keyword_cache: Dict[str, Dict[str, Any]] = {}
_dense_cache: Dict[str, Dict[str, Any]] = {}
_hold_cost_cache: Dict[int, Dict[str, Any]] = {}


def _force_ipv4() -> None:
    if os.getenv("VALUESCAN_FORCE_IPV4", "1").lower() not in ("1", "true", "yes", "on"):
        return
    try:
        import urllib3.util.connection as urllib3_cn
        urllib3_cn.allowed_gai_family = lambda: socket.AF_INET
    except Exception as exc:
        _log("warning", "[ValueScan] Failed to force IPv4: %s", exc)


_force_ipv4()


def _now() -> float:
    return time.time()


def _log(level: str, msg: str, *args: Any) -> None:
    if logger:
        getattr(logger, level, logger.info)(msg, *args)


def _load_localstorage(path: Optional[Path] = None) -> Dict[str, Any]:
    target = path or DEFAULT_LOCALSTORAGE
    if not target or not target.exists():
        return {}
    try:
        return json.loads(target.read_text(encoding="utf-8"))
    except Exception as exc:
        _log("warning", "[ValueScan] Failed to read localstorage: %s", exc)
        return {}


def _extract_token(localstorage: Dict[str, Any]) -> str:
    token = (
        localstorage.get("account_token")
        or localstorage.get("accessToken")
        or localstorage.get("token")
        or ""
    )
    if isinstance(token, str):
        return token.strip()
    return ""


def _extract_access_ticket(localstorage: Dict[str, Any]) -> str:
    keys = ("access_ticket", "accessTicket", "accessTicketValue", "access-ticket")
    for key in keys:
        val = localstorage.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
    if isinstance(localstorage.get("data"), dict):
        nested = localstorage["data"]
        for key in keys:
            val = nested.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
    return ACCESS_TICKET_FALLBACK


def _auth_headers(token: str, access_ticket: str) -> Dict[str, str]:
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Origin": DEFAULT_ORIGIN,
        "Referer": f"{DEFAULT_ORIGIN}/",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if access_ticket:
        headers["Access-Ticket"] = access_ticket
    return headers


def _get_valuescan_proxies() -> Optional[Dict[str, str]]:
    proxy_url = (
        os.getenv("VALUESCAN_API_PROXY")
        or os.getenv("VALUESCAN_PROXY")
        or os.getenv("HTTPS_PROXY")
        or os.getenv("HTTP_PROXY")
        or ""
    ).strip()
    if not proxy_url:
        try:
            from config import HTTP_PROXY as CONFIG_HTTP_PROXY
        except Exception:
            CONFIG_HTTP_PROXY = ""
        if isinstance(CONFIG_HTTP_PROXY, str) and CONFIG_HTTP_PROXY.strip():
            proxy_url = CONFIG_HTTP_PROXY.strip()
    if not proxy_url:
        return None
    return {"http": proxy_url, "https": proxy_url}


class _TLS12Adapter(HTTPAdapter):
    def __init__(self, verify: bool) -> None:
        self._verify = bool(verify)
        super().__init__()

    def init_poolmanager(self, connections, maxsize, block=False, **pool_kwargs):
        ctx = ssl.create_default_context()
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.maximum_version = ssl.TLSVersion.TLSv1_2
        if not self._verify:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        self.poolmanager = PoolManager(
            num_pools=connections,
            maxsize=maxsize,
            block=block,
            ssl_context=ctx,
        )


def build_valuescan_session(verify: bool) -> requests.Session:
    session = requests.Session()
    force_tls12 = os.getenv("VALUESCAN_API_FORCE_TLS12", "1").lower() in ("1", "true", "yes", "on")
    if force_tls12:
        try:
            session.mount("https://", _TLS12Adapter(verify))
        except Exception as exc:
            _log("warning", "[ValueScan] TLS12 adapter init failed: %s", exc)
    return session


def build_valuescan_headers() -> Dict[str, str]:
    """Build ValueScan API auth headers from localstorage/token info."""
    localstorage = _load_localstorage()
    token = _extract_token(localstorage)
    access_ticket = _extract_access_ticket(localstorage)
    return _auth_headers(token, access_ticket)


def get_valuescan_base_url() -> str:
    return BASE_URL


def get_valuescan_proxies() -> Optional[Dict[str, str]]:
    return _get_valuescan_proxies()


def _post(path: str, payload: Dict[str, Any], token: Optional[str] = None) -> Optional[Dict[str, Any]]:
    _force_ipv4()
    localstorage = _load_localstorage()
    token = (token or _extract_token(localstorage)).strip()
    access_ticket = _extract_access_ticket(localstorage)
    if not token:
        _log("warning", "[ValueScan] Missing token for %s, trying access ticket only", path)
    url = f"{BASE_URL}{path}"
    max_retries = int(os.getenv("VALUESCAN_API_RETRY", "3") or 3)
    timeout_sec = float(os.getenv("VALUESCAN_API_TIMEOUT", "15") or 15)
    connect_timeout = float(os.getenv("VALUESCAN_API_CONNECT_TIMEOUT", "8") or 8)
    verify = os.getenv("VALUESCAN_API_VERIFY", "1").lower() not in ("0", "false", "no", "off")
    proxies = _get_valuescan_proxies()
    use_env_proxy = os.getenv("VALUESCAN_API_TRUST_ENV", "0").lower() in ("1", "true", "yes", "on")
    for attempt in range(max_retries + 1):
        try:
            session = build_valuescan_session(verify)
            session.trust_env = bool(use_env_proxy and not proxies)
            resp = session.post(
                url,
                headers=_auth_headers(token, access_ticket),
                json=payload,
                timeout=(connect_timeout, timeout_sec),
                proxies=proxies,
                verify=verify,
            )
        except Exception as exc:
            if attempt < max_retries:
                time.sleep(0.6 + attempt * 0.6)
                continue
            _log("warning", "[ValueScan] Request failed %s: %s", path, exc)
            return None
        try:
            return resp.json()
        except Exception as exc:
            if attempt < max_retries:
                time.sleep(0.6 + attempt * 0.6)
                continue
            _log("warning", "[ValueScan] Bad JSON for %s: %s", path, exc)
            return None


def _normalize_symbol(symbol: str) -> str:
    return str(symbol or "").upper().replace("$", "").replace("USDT", "").strip()


def _parse_token_history(localstorage: Dict[str, Any]) -> List[Dict[str, Any]]:
    raw = localstorage.get("token_history")
    if isinstance(raw, list):
        return [item for item in raw if isinstance(item, dict)]
    if isinstance(raw, str):
        try:
            data = json.loads(raw)
        except Exception:
            return []
        if isinstance(data, list):
            return [item for item in data if isinstance(item, dict)]
    return []


def _parse_query_list(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    if data.get("code") != 200:
        return []
    container = data.get("data") or {}
    items = container.get("list")
    if isinstance(items, list):
        return [item for item in items if isinstance(item, dict)]
    return []


def query_coin(keyword: str) -> List[Dict[str, Any]]:
    payload = {"search": keyword, "page": 1, "pageSize": 20}
    data = _post("/api/vs-token/queryCoin", payload) or {}
    items = _parse_query_list(data)
    if items:
        return items
    fallback = _post("/api/vs-token/queryCoin", {"keyword": keyword}) or {}
    return _parse_query_list(fallback)


def resolve_keyword(symbol: str) -> Optional[int]:
    normalized = _normalize_symbol(symbol)
    if not normalized:
        return None

    cached = _keyword_cache.get(normalized)
    if cached and _now() - cached["ts"] < _CACHE_TTL_SEC:
        return cached["value"]

    localstorage = _load_localstorage()
    for item in _parse_token_history(localstorage):
        if str(item.get("symbol", "")).upper() == normalized:
            keyword = item.get("keyword") or item.get("vsTokenId")
            try:
                value = int(float(keyword))
            except Exception:
                value = None
            if value:
                _keyword_cache[normalized] = {"value": value, "ts": _now()}
                return value

    items = query_coin(normalized)
    match = None
    for item in items:
        if str(item.get("symbol", "")).upper() == normalized:
            match = item
            break
    if not match:
        return None
    keyword = match.get("vsTokenId") or match.get("keyword")
    try:
        value = int(float(keyword))
    except Exception:
        return None
    _keyword_cache[normalized] = {"value": value, "ts": _now()}
    return value


def _point_time_ms(point: Dict[str, Any]) -> int:
    if not isinstance(point, dict):
        return 0
    for key in (
        "time",
        "ts",
        "timestamp",
        "dateTime",
        "date",
        "createTime",
        "create_time",
        "updateTime",
        "update_time",
        "timeStamp",
    ):
        value = point.get(key)
        if value is None:
            continue
        try:
            ts = int(float(value))
        except Exception:
            if isinstance(value, str):
                text = value.strip().replace("Z", "+00:00")
                dt = None
                try:
                    dt = datetime.fromisoformat(text)
                except Exception:
                    for fmt in (
                        "%Y-%m-%d %H:%M:%S",
                        "%Y-%m-%d %H:%M",
                        "%Y/%m/%d %H:%M:%S",
                        "%Y/%m/%d %H:%M",
                        "%Y-%m-%d",
                        "%Y/%m/%d",
                    ):
                        try:
                            dt = datetime.strptime(text, fmt)
                            break
                        except Exception:
                            continue
                if dt:
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    return int(dt.timestamp() * 1000)
            continue
        if ts <= 0:
            continue
        return ts if ts > 10**12 else ts * 1000
    return 0


def _filter_points_by_days(points: List[Dict[str, Any]], days: int) -> List[Dict[str, Any]]:
    if days <= 0:
        return points
    cutoff_ms = int(_now() * 1000) - days * 24 * 60 * 60 * 1000
    return [p for p in points if _point_time_ms(p) >= cutoff_ms]


def _extract_dense_points(resp: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not isinstance(resp, dict):
        return []
    data = resp.get("data")
    if isinstance(data, list):
        if data and isinstance(data[0], (list, tuple)) and len(data[0]) >= 2:
            converted = []
            for row in data:
                if not isinstance(row, (list, tuple)) or len(row) < 2:
                    continue
                converted.append({"time": row[0], "price": row[1]})
            return converted
        return data
    if isinstance(data, dict):
        for key in ("list", "records", "items", "history", "historyList", "kline", "klineList", "bars"):
            if isinstance(data.get(key), list):
                return data.get(key) or []
    return []


def _dense_point_price(item: Dict[str, Any]) -> Optional[float]:
    if not isinstance(item, dict):
        return None
    for key in (
        "price",
        "levelPrice",
        "val",
        "value",
        "cost",
        "priceLevel",
        "avgPrice",
        "priceAvg",
        "costPrice",
        "avg_cost",
        "close",
        "last",
    ):
        value = item.get(key)
        if value is None:
            continue
        try:
            return float(value)
        except Exception:
            continue
    low = item.get("low") or item.get("minPrice") or item.get("priceMin")
    high = item.get("high") or item.get("maxPrice") or item.get("priceMax")
    if low is not None and high is not None:
        try:
            return (float(low) + float(high)) / 2
        except Exception:
            pass
    text = item.get("priceRange") or item.get("range") or ""
    if isinstance(text, str) and "-" in text:
        parts = [p.strip() for p in text.split("-", 1)]
        if len(parts) == 2:
            try:
                low = float(parts[0])
                high = float(parts[1])
                return (low + high) / 2
            except Exception:
                return None
    return None


def _dedupe_levels(levels: List[float], precision: int = 6) -> List[float]:
    seen = set()
    out: List[float] = []
    for value in levels:
        try:
            price = float(value)
        except Exception:
            continue
        key = round(price, precision)
        if key in seen:
            continue
        seen.add(key)
        out.append(price)
    return out


def _fetch_symbol_price(symbol: str) -> Optional[float]:
    items = query_coin(symbol)
    target = None
    for item in items:
        if str(item.get("symbol", "")).upper() == _normalize_symbol(symbol):
            target = item
            break
    if not target:
        return None
    try:
        return float(target.get("price", 0) or 0)
    except Exception:
        return None


def get_dense_area(keyword: int, days: int = DEFAULT_DENSE_DAYS) -> Optional[Dict[str, Any]]:
    cache_key = f"{keyword}:{days}"
    cached = _dense_cache.get(cache_key)
    if cached and _now() - cached["ts"] < _CACHE_TTL_SEC:
        return cached["value"]

    end_ms = int(_now() * 1000)
    begin_ms = end_ms - days * 24 * 60 * 60 * 1000
    payload = {
        "vsTokenId": str(keyword),
        "beginTime": begin_ms,
        "endTime": end_ms,
    }
    resp = _post("/api/dense/getDenseAreaKLineHistory", payload) or {}
    if resp.get("code") == 200 and resp.get("data"):
        _dense_cache[cache_key] = {"value": resp, "ts": _now()}
        return resp

    fallback = _post(
        "/api/dense/getDenseAreaKLineHistory",
        {"beginTime": begin_ms, "endTime": end_ms},
    )
    if isinstance(fallback, dict):
        _dense_cache[cache_key] = {"value": fallback, "ts": _now()}
    return fallback or resp


def get_main_force(symbol: str, days: int = DEFAULT_DENSE_DAYS) -> Dict[str, Any]:
    keyword = resolve_keyword(symbol)
    if not keyword:
        return {"code": 404, "error": f"Coin '{symbol}' not found"}

    last_resp: Dict[str, Any] = {"code": 500, "error": "No dense area data"}
    last_points: List[Dict[str, Any]] = []

    candidate_days = [days, max(days * 2, 30), 60, 90]
    seen = set()
    for window in candidate_days:
        if window in seen:
            continue
        seen.add(window)
        resp = get_dense_area(keyword, window) or {}
        last_resp = resp
        if resp.get("code") != 200:
            continue
        points = _extract_dense_points(resp)
        if not points:
            continue
        points_sorted = sorted(points, key=_point_time_ms)
        last_points = points_sorted
        has_timestamp = any(_point_time_ms(point) > 0 for point in points_sorted)
        if not has_timestamp and len(points_sorted) >= 1:
            return {"code": 200, "data": points_sorted}

        filtered = _filter_points_by_days(points_sorted, days)
        if len(filtered) >= 1:
            return {"code": 200, "data": filtered}

        widened = _filter_points_by_days(points_sorted, window)
        if len(widened) >= 1:
            return {"code": 200, "data": widened}

    if len(last_points) >= 1:
        return {"code": 200, "data": last_points[-7:]}
    if isinstance(last_resp, dict):
        return last_resp
    return {"code": 500, "error": "No dense area data"}


def get_hold_cost(keyword: int, days: int = 90) -> Optional[Dict[str, Any]]:
    cached = _hold_cost_cache.get(keyword)
    if cached and _now() - cached["ts"] < _CACHE_TTL_SEC:
        return cached["value"]

    end_ms = int(_now() * 1000)
    begin_ms = end_ms - days * 24 * 60 * 60 * 1000
    data = _post(
        "/api/track/judge/coin/getHoldCost",
        {"keyword": keyword, "begin": begin_ms, "end": end_ms},
    ) or {}
    if data.get("code") != 200:
        return None
    payload = data.get("data")
    if not isinstance(payload, dict):
        return None
    _hold_cost_cache[keyword] = {"value": payload, "ts": _now()}
    return payload


def get_valuescan_key_levels(
    symbol: str,
    current_price: Optional[float] = None,
    days: Optional[int] = None,
) -> Optional[Dict[str, Any]]:
    dense_days = days if days is not None else DEFAULT_DENSE_DAYS
    resp = get_main_force(symbol, days=dense_days)
    if resp.get("code") != 200:
        return None
    points = resp.get("data") or []
    if not isinstance(points, list) or not points:
        return None
    type_values = {item.get("type") for item in points if isinstance(item, dict) and item.get("type") is not None}
    if type_values and 2 in type_values:
        filtered_points = [item for item in points if isinstance(item, dict) and item.get("type") == 2]
        if filtered_points:
            points = filtered_points

    points_sorted = sorted(points, key=_point_time_ms)
    recent_points = points_sorted
    levels: List[float] = []
    for item in recent_points:
        price = _dense_point_price(item)
        if price is None:
            continue
        levels.append(price)
    if not levels:
        return None

    levels = _dedupe_levels(levels)
    return {
        "levels": levels,
        "supports": [],
        "resistances": [],
        "meta": {
            "source": "VS",
            "mode": "window",
            "days": dense_days,
            "count": len(levels),
        },
    }
